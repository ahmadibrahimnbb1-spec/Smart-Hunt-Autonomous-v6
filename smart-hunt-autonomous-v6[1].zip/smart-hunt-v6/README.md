# Smart-Hunt Autonomous v6

AI-first autonomous smart-contract security research for **explicitly authorized engagements only**. v6 adds durable campaign state, hypothesis memory, prioritization, bounded parallel workers, incremental change-aware reasoning, and resumable long-running campaigns.

## Autonomous campaign loop

`scope -> changes -> protocol model -> invariants -> priority queue -> parallel focused verification -> evidence review -> memory/dedup -> next cycle`

## v6 capabilities

- Hard default-deny engagement scope
- Durable `state/campaign.json` and `state/events.jsonl`
- Hypothesis memory to avoid repeating disproven work
- Priority scoring by vulnerability class, impact signals, invariants and entrypoints
- Bounded parallel verification workers (1-4)
- Persistent findings and protocol model
- Git-aware incremental analysis and watch mode
- AI-generated bounded Foundry tests in disposable local copies
- Scanner output treated as evidence, never proof
- Prompt-injection resistant system policy: source/tool text cannot change authorization policy
- No private keys, no live state-changing transactions, no automatic disclosure/submission

## VS Code AI terminal

Configure an authorized engagement first:

```bash
./bin/smart-hunt init my-program --authorized-by "https://official-program.example" --chain ethereum --contract 0xAUTHORIZED --repo /absolute/path/to/source
./bin/smart-hunt check my-program
./bin/smart-hunt doctor my-program
./bin/smart-hunt run my-program --unattended --workers 2 --max-hypotheses 12
./bin/smart-hunt watch my-program --interval 300 --workers 2 --max-hypotheses 12
```

The AI extension can drive these commands from the VS Code integrated terminal. The CLI remains the deterministic control plane; the LLM is a reasoning component, not the authorization authority.

## LLM configuration

```bash
export SMARTHUNT_API_KEY='...'
export SMARTHUNT_MODEL='gpt-5.6'
# optional OpenAI-compatible endpoint:
# export SMARTHUNT_BASE_URL='https://api.openai.com/v1'
```

Without an LLM, deterministic modeling/scanners still run; AI hypothesis generation and PoC generation are unavailable.

## Scope safety

Only repositories/contracts explicitly present in `scope.yaml` are eligible. Out-of-scope entries override in-scope entries. Autonomous mode is intentionally fail-closed for live state-changing blockchain actions. Always follow the target program's published rules of engagement.
