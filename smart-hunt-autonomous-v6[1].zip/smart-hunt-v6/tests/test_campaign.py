import json, tempfile
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'lib'))
from campaign import CampaignStore
from priority import prioritize

def test_campaign_persists():
    with tempfile.TemporaryDirectory() as d:
        c=CampaignStore(Path(d)); c.begin_cycle(1); hid=c.upsert_hypothesis({'id':'h1','type':'reentrancy'},'queued'); c.set_hypothesis(hid,'completed',{'result':{'status':'rejected'}}); c.record_finding({'title':'x','root_cause':'y','affected_files':['A.sol'],'evidence':'local'}); c2=CampaignStore(Path(d)); assert c2.data['cycle']==1; assert 'h1' in c2.data['hypotheses']; assert len(c2.data['findings'])==1

def test_priority():
    hs=[{'id':'a','type':'precision'},{'id':'b','type':'accounting','impact_estimate':'high financial','broken_invariant':'solvency'}]
    assert prioritize(hs)[0]['id']=='b'
