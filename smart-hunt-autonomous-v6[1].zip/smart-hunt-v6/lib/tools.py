from __future__ import annotations
import shutil, subprocess, json
TOOLS=['git','python3','forge','cast','anvil','slither','solc','medusa','aderyn','echidna-test']
def available(): return {t:bool(shutil.which(t)) for t in TOOLS}
def report():
 for k,v in available().items(): print(f'{k:14} '+('OK' if v else 'MISSING'))
def run(cmd,cwd=None,timeout=300):
 try: return subprocess.run(cmd,cwd=cwd,text=True,capture_output=True,check=False,timeout=timeout)
 except subprocess.TimeoutExpired as e: return subprocess.CompletedProcess(cmd,124,'',f'timeout: {e}')

def safe_scanners(repo,outdir):
 out=[]; outdir.mkdir(parents=True,exist_ok=True)
 if shutil.which('slither'):
  p=run(['slither',str(repo),'--json',str(outdir/'slither.json')],timeout=600); out.append({'tool':'slither','returncode':p.returncode,'stdout':p.stdout[-12000:],'stderr':p.stderr[-12000:]})
 if shutil.which('aderyn'):
  p=run(['aderyn','--output',str(outdir/'aderyn.txt'),str(repo)],timeout=600); out.append({'tool':'aderyn','returncode':p.returncode,'stdout':p.stdout[-12000:],'stderr':p.stderr[-12000:]})
 return out
