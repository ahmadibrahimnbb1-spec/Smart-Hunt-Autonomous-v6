from __future__ import annotations
import json,time,concurrent.futures
from pathlib import Path
from engagement import Engagement
from change_tracker import ChangeTracker
from tools import available,safe_scanners
from scope_guard import ContractScope
from agent import AutonomousAgent
from verification import LocalVerifier
from protocol_model import build_model
from deep_model import build_deep_model
from invariant_engine import mine_invariants
from fuzz_strategy import build_fuzz_plan
from campaign import CampaignStore
from priority import prioritize
from memory import HuntMemory

class Coordinator:
 def __init__(self,root,unattended=False,no_llm=False,workers=2,max_hypotheses=12):
  self.root=Path(root); self.e=Engagement.load(self.root); self.scope=ContractScope(self.e.scope_path); self.unattended=unattended; self.no_llm=no_llm; self.workers=max(1,min(workers,4)); self.max_hypotheses=max(1,min(max_hypotheses,24)); self.campaign=CampaignStore(self.root); self.memory=HuntMemory(self.root)
 def cycle(self,n):
  self.e.check_authorization(); self.scope.validate(); self.campaign.begin_cycle(n)
  delta=ChangeTracker(self.root).snapshot(); (self.root/'runs').mkdir(exist_ok=True); (self.root/'evidence').mkdir(exist_ok=True)
  scanner=[]
  for repo in self.e.repos:
   p=Path(repo).resolve()
   if self.scope.repo_allowed(p) and p.exists(): scanner += safe_scanners(p,self.root/'evidence'/f'cycle-{n}')
  changed_files=delta.get('solidity_files',[]); models=[]
  for repo in self.e.repos:
   rp=Path(repo).resolve()
   if not (self.scope.repo_allowed(rp) and rp.exists()): continue
   selected=[Path(x).resolve() for x in changed_files if Path(x).exists() and (rp==Path(x).resolve() or rp in Path(x).resolve().parents)]
   if not selected: selected=[p for p in rp.rglob('*.sol') if '.git' not in p.parts][:160]
   base=build_model(rp,[str(x) for x in selected]); base['deep']=build_deep_model(rp,selected); base['candidate_invariants']=mine_invariants(base['deep'])+base.get('candidate_invariants',[]); models.append(base)
  merged={i['id']:i for m in models for i in m.get('candidate_invariants',[])}
  protocol_model={'repositories':models,'candidate_invariants':sorted(merged.values(),key=lambda x:x['id']),'fuzz_plan':build_fuzz_plan({'deep':{'function_nodes':[n for m in models for n in m.get('deep',{}).get('function_nodes',[])]}},list(merged.values()))}
  (self.root/'state'/'protocol_model.json').write_text(json.dumps(protocol_model,indent=2,default=str)); self.campaign.remember('latest_protocol_model',protocol_model)
  agent=AutonomousAgent(self.e,self.scope,available(),self.no_llm)
  verifier_engine=LocalVerifier(self.e,agent.llm,self.scope)
  def verifier(h,ctx):
   files=h.get('files') or delta.get('solidity_files',[]); candidates=[Path(f).resolve() for f in files if Path(f).exists()]
   for repo in self.e.repos:
    rp=Path(repo).resolve()
    if self.scope.repo_allowed(rp) and any(rp==c or rp in c.parents for c in candidates): return verifier_engine.verify(rp,h,ctx)
   return {'status':'blocked','reason':'no authorized repository matched hypothesis files'}
  ctx=agent.model_context(delta,scanner,protocol_model); raw_plan=agent.plan(ctx); raw_plan['hypotheses']=prioritize(raw_plan.get('hypotheses',[]),self.max_hypotheses)
  # Reuse durable memory: don't repeatedly spend budget on identical rejected hypotheses.
  queue=[h for h in raw_plan.get('hypotheses',[]) if not self.memory.known(h)]
  for h in queue: self.campaign.upsert_hypothesis(h,'queued')
  results=[]
  def run_one(h):
   hid=h.get('id'); self.campaign.set_hypothesis(hid,'running');
   try:
    r=verifier(h,ctx); self.memory.record(h,'verified' if r.get('status') in ('passed','confirmed') else 'rejected',r); self.campaign.set_hypothesis(hid,'completed',{'result':r}); return {'hypothesis':h,'result':r}
   except Exception as exc:
    self.memory.record(h,'error',{'error':str(exc)}); self.campaign.set_hypothesis(hid,'error',{'error':str(exc)}); return {'hypothesis':h,'result':{'status':'error','error':str(exc)}}
  with concurrent.futures.ThreadPoolExecutor(max_workers=self.workers) as pool:
   for item in pool.map(run_one,queue): results.append(item)
  verification=agent.verify(ctx,raw_plan,results)
  for f in verification.get('findings',[]) or []:
   self.campaign.record_finding(f); self.memory.record_finding(f)
  state={'cycle':n,'delta':delta,'tools':available(),'mode':'unattended' if self.unattended else 'interactive','scanner_results':scanner,'protocol_model':protocol_model,'plan':raw_plan,'skipped_known_hypotheses':len(raw_plan.get('hypotheses',[]))-len(queue),'verification_runs':results,'verification':verification}
  (self.root/'runs'/f'cycle-{n}.json').write_text(json.dumps(state,indent=2,default=str)); self.campaign.end_cycle('completed')
  print(f'cycle {n}: files={len(delta["solidity_files"])} changed={len(delta["changed"])} queued={len(queue)} skipped_known={state["skipped_known_hypotheses"]} findings={len(verification.get("findings",[]) or [])}')
 def run(self,cycles=1,interval=300):
  for i in range(1,cycles+1): self.cycle(i); 
 def watch(self,interval=300):
  i=int(self.campaign.data.get('cycle',0))
  while not (self.root/'STOP').exists():
   i+=1
   try: self.cycle(i)
   except Exception as e:
    self.campaign.event('cycle_error',{'error':str(e)}); self.campaign.end_cycle('error'); print(f'cycle {i}: ERROR {e}')
   time.sleep(max(5,interval))
