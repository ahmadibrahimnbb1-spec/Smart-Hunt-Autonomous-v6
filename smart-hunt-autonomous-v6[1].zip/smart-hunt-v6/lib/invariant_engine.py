from __future__ import annotations
import re

def mine_invariants(model: dict) -> list[dict]:
    inv=[]; seen=set()
    def add(i, kind, statement, signals):
        if i not in seen: seen.add(i); inv.append({'id':i,'kind':kind,'statement':statement,'signals':signals})
    nodes=model.get('function_nodes',[])
    state={x['state'] for x in model.get('storage_dataflow',[])}
    asset=model.get('asset_flow',[])
    if any(re.search(r'total|balance|share|reserve|debt|supply',s,re.I) for s in state) or asset:
        add('accounting-conservation','economic','Asset/share/debt accounting should remain internally consistent across every state-changing path.',sorted(state)[:30])
    if model.get('external_interactions'):
        add('interaction-safety','control-flow','Security-sensitive state must remain valid across every external interaction and callback.',[x['function'] for x in model['external_interactions']])
    if model.get('privilege_flow'):
        add('privilege-integrity','authorization','Administrative or privileged state changes must require the intended role and must not be reachable through an unprivileged path.',[x['function'] for x in model['privilege_flow']])
    if any(n['oracle_signals'] for n in nodes):
        add('oracle-integrity','market','Price/rate inputs must be fresh, bounded, correctly scaled and resistant to manipulation for their economic use.',sorted({s for n in nodes for s in n['oracle_signals']}))
    if any(re.search(r'permit|nonce|signature|ecrecover',str(n),re.I) for n in nodes):
        add('signature-domain','authentication','Signed actions must bind signer, domain, nonce/deadline and intended parameters; replay across contexts must be impossible.',[])
    if any(re.search(r'upgrade|delegatecall|proxy|implementation',str(n),re.I) for n in nodes):
        add('upgrade-integrity','upgradeability','Upgrade and implementation changes must preserve storage layout, authorization and initialization invariants.',[])
    if any(re.search(r'rounding|decimals|mul|div|wad|ray',str(n),re.I) for n in nodes):
        add('precision-safety','numeric','Rounding and decimal conversions must not create exploitable value leakage or asymmetric accounting.',[])
    return inv
