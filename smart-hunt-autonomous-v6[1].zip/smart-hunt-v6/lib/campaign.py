from __future__ import annotations
import hashlib, json, time
from pathlib import Path
from typing import Any

class CampaignStore:
    """Durable, append-only-ish campaign state for long autonomous hunts."""
    def __init__(self, root: Path):
        self.root=Path(root); self.state_dir=self.root/'state'; self.state_dir.mkdir(parents=True,exist_ok=True)
        self.path=self.state_dir/'campaign.json'; self.events=self.state_dir/'events.jsonl'
        self.data=self._load()
    def _load(self):
        if self.path.exists():
            try: return json.loads(self.path.read_text())
            except Exception: pass
        return {'version':1,'campaign_id':hashlib.sha256(str(self.root.resolve()).encode()).hexdigest()[:16],
                'cycle':0,'status':'idle','hypotheses':{},'findings':{},'memory':{},'budgets':{},'metrics':{}}
    def save(self): self.path.write_text(json.dumps(self.data,indent=2,default=str))
    def event(self, kind:str, payload:dict[str,Any]):
        rec={'ts':time.time(),'kind':kind,'cycle':self.data.get('cycle',0),'payload':payload}
        with self.events.open('a') as f: f.write(json.dumps(rec,default=str)+'\n')
    def begin_cycle(self,n:int):
        self.data['cycle']=n; self.data['status']='running'; self.data.setdefault('metrics',{}); self.data['metrics']['started_at']=time.time(); self.save(); self.event('cycle_started',{'cycle':n})
    def end_cycle(self,status='completed'):
        self.data['status']=status; self.data['metrics']['ended_at']=time.time(); self.save(); self.event('cycle_ended',{'status':status})
    def upsert_hypothesis(self,h:dict[str,Any],status='queued'):
        hid=str(h.get('id') or hashlib.sha256(json.dumps(h,sort_keys=True,default=str).encode()).hexdigest()[:16])
        rec=self.data['hypotheses'].get(hid,{})
        rec.update(h); rec['id']=hid; rec['status']=status; rec['updated_at']=time.time(); rec.setdefault('attempts',0)
        self.data['hypotheses'][hid]=rec; self.save(); return hid
    def set_hypothesis(self,hid,status,extra=None):
        h=self.data['hypotheses'].setdefault(hid,{'id':hid}); h['status']=status; h['updated_at']=time.time(); h.update(extra or {}); self.save(); self.event('hypothesis_status',{'id':hid,'status':status})
    def remember(self,key,value): self.data.setdefault('memory',{})[key]=value; self.save()
    def record_finding(self,finding):
        raw=json.dumps({k:finding.get(k) for k in ('title','root_cause','affected_files','evidence')},sort_keys=True,default=str)
        fid=hashlib.sha256(raw.encode()).hexdigest()[:16]
        finding=dict(finding); finding['id']=fid; finding['first_seen_cycle']=self.data.get('cycle'); self.data['findings'][fid]=finding; self.save(); self.event('finding_recorded',finding); return fid
