from __future__ import annotations
import json, re
from pathlib import Path
from collections import defaultdict

FUNC_RE = re.compile(r'function\s+(\w+)\s*\(([^)]*)\)[^{;]*\{', re.M)
MOD_RE = re.compile(r'modifier\s+(\w+)\s*\(([^)]*)\)?[^\{]*\{', re.M)
CONTRACT_RE = re.compile(r'\b(contract|interface|library)\s+(\w+)\b[^\{]*\{', re.M)
EVENT_RE = re.compile(r'\bevent\s+(\w+)\s*\(([^)]*)\)', re.M)
STATE_RE = re.compile(r'^\s*(?:mapping\s*\([^;]+\)|(?:uint\d*|int\d*|address|bool|bytes\d*|bytes|string)\s+[^;=]+)\s*(?:=[^;]+)?;', re.M)
ADDRESS_RE = re.compile(r'0x[a-fA-F0-9]{40}')
CALL_RE = re.compile(r'\b(?:\.call\s*\{|\.call\s*\(|\.delegatecall\s*\(|\.staticcall\s*\(|\.transfer\s*\(|\.send\s*\()', re.M)
PRIV_RE = re.compile(r'\b(onlyOwner|onlyRole|AccessControl|Ownable|_authorizeUpgrade|admin|owner|guardian|pauser|operator)\b')
VALUE_RE = re.compile(r'\b(?:balances?|amount|assets?|shares?|totalSupply|totalAssets|allowance|debt|reserve|fee|price|rate|oracle|nonce)\b', re.I)


def _brace_body(text: str, start: int) -> str:
    depth = 0; seen = False; out=[]
    for ch in text[start:]:
        if ch == '{': depth += 1; seen = True
        elif ch == '}':
            depth -= 1
            if seen and depth == 0: break
        if seen: out.append(ch)
    return ''.join(out)


def build_model(repo: Path, files: list[str], max_chars: int = 180_000) -> dict:
    repo = repo.resolve(); selected=[]
    for raw in files:
        p=Path(raw).resolve()
        if p.exists() and (p==repo or repo in p.parents) and p.suffix=='.sol': selected.append(p)
    if not selected:
        selected=[p for p in repo.rglob('*.sol') if '.git' not in p.parts][:80]
    contracts=[]; functions=[]; state=[]; calls=[]; privileges=[]; events=[]; addresses=[]
    for p in selected:
        text=p.read_text(errors='replace')[:max_chars]
        rel=str(p.relative_to(repo))
        for m in CONTRACT_RE.finditer(text): contracts.append({'name':m.group(2),'kind':m.group(1),'file':rel})
        for m in EVENT_RE.finditer(text): events.append({'name':m.group(1),'file':rel})
        for m in STATE_RE.finditer(text):
            line=m.group(0).strip(); state.append({'file':rel,'declaration':line[:500]})
        for m in FUNC_RE.finditer(text):
            body=_brace_body(text,m.end()-1)
            header=text[m.start():m.end()].replace('{','').strip()
            visibility=re.search(r'\b(public|external|internal|private)\b',header)
            modifiers=re.findall(r'\b([A-Za-z_]\w*)\s*(?:\([^)]*\))?(?=\s*\{?$)',header)
            rec={'name':m.group(1),'file':rel,'signature':header[:700],'visibility':visibility.group(1) if visibility else 'unknown','modifiers':modifiers[-8:],'external_calls':len(CALL_RE.findall(body)),'value_sensitive':bool(VALUE_RE.search(body)),'body_excerpt':body[:1800]}
            functions.append(rec)
            if rec['external_calls']: calls.append({'file':rel,'function':rec['name'],'count':rec['external_calls']})
            hits=sorted(set(x.group(1) for x in PRIV_RE.finditer(header+'\n'+body)))
            if hits: privileges.append({'file':rel,'function':rec['name'],'signals':hits})
        addresses += ADDRESS_RE.findall(text)
    # Lightweight dependency edges: calls to known function names in the same model.
    names={f['name'] for f in functions}
    edges=[]
    for f in functions:
        for n in names:
            if n != f['name'] and re.search(r'\b'+re.escape(n)+r'\s*\(', f['body_excerpt']): edges.append({'from':f['name'],'to':n,'file':f['file']})
    invariants=[]
    alltext='\n'.join(x['declaration'] for x in state)
    if re.search(r'totalSupply|totalAssets|totalShares', alltext, re.I): invariants.append({'id':'accounting-conservation','statement':'asset/share accounting should remain internally consistent across mint/burn/deposit/withdraw paths'})
    if any(x['external_calls'] for x in functions): invariants.append({'id':'checks-effects-interactions','statement':'security-sensitive state should not be left inconsistent across external calls or callbacks'})
    if privileges: invariants.append({'id':'privilege-boundary','statement':'administrative state changes must be restricted to authorized roles'})
    if re.search(r'price|oracle|rate', json.dumps(functions), re.I): invariants.append({'id':'price-integrity','statement':'financial calculations must use trusted, bounded and manipulation-resistant price inputs'})
    if re.search(r'nonce|signature|permit', json.dumps(functions), re.I): invariants.append({'id':'signature-replay','statement':'signed actions must be bound to domain, signer, nonce and intended action'})
    return {'repo':str(repo),'files':[str(p) for p in selected],'contracts':contracts,'functions':functions,'state_variables':state,'external_calls':calls,'privileged_functions':privileges,'events':events,'call_edges':edges[:1200],'embedded_addresses':sorted(set(addresses)),'candidate_invariants':invariants}
