from __future__ import annotations
import hashlib, json, subprocess
from pathlib import Path
class ChangeTracker:
 def __init__(self,root): self.root=Path(root); self.state=self.root/'state'/'snapshot.json'
 def repos(self):
  import yaml
  cfg=yaml.safe_load((self.root/'scope.yaml').read_text()) or {}; return [Path(x).resolve() for x in cfg.get('in_scope_repositories',[]) or []]
 def _git(self,r):
  try: return subprocess.check_output(['git','-C',str(r),'rev-parse','HEAD'],text=True,stderr=subprocess.DEVNULL).strip()
  except Exception: return None
 def _diff(self,r,old_commit,new_commit):
  if not old_commit or not new_commit or old_commit==new_commit: return []
  try:
   x=subprocess.check_output(['git','-C',str(r),'diff','--name-only',old_commit,new_commit,'--','*.sol'],text=True,stderr=subprocess.DEVNULL)
   return [str((r/p).resolve()) for p in x.splitlines() if p.strip()]
  except Exception: return []
 def files(self,r): return sorted(str(p) for p in r.rglob('*.sol') if '.git' not in p.parts)
 def snapshot(self):
  old=json.loads(self.state.read_text()) if self.state.exists() else {}
  cur={}; added=[]; changed=[]; removed=[]; commits=[]
  for r in self.repos():
   if not r.exists(): continue
   commit=self._git(r); prev=old.get(str(r),{}); nowfiles=self.files(r); prevfiles=set(prev.get('files',[])); nowset=set(nowfiles)
   added+=sorted(nowset-prevfiles); removed+=sorted(prevfiles-nowset); changed+=self._diff(r,prev.get('commit'),commit)
   if commit and commit!=prev.get('commit'): commits.append({'repo':str(r),'from':prev.get('commit'),'to':commit})
   cur[str(r)]={'commit':commit,'files':nowfiles}
  allchanged=sorted(set(added+changed))
  out={'added':added,'removed':removed,'changed':changed,'solidity_files':allchanged,'commits':commits,'repos':cur,'first_run':not bool(old)}
  self.state.parent.mkdir(exist_ok=True); self.state.write_text(json.dumps(cur,indent=2)); return out
