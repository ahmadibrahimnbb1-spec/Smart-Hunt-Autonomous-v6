from __future__ import annotations
import yaml
from pathlib import Path
class ScopeViolation(RuntimeError): pass
class ContractScope:
 def __init__(self,path):
  self.path=Path(path); self.cfg=yaml.safe_load(self.path.read_text()) or {}
  self.allowed={x.lower() for x in self.cfg.get('in_scope_contracts',[]) or []}; self.denied={x.lower() for x in self.cfg.get('out_of_scope_contracts',[]) or []}
 def contract_allowed(self,address):
  a=address.lower()
  if a in self.denied: return False
  return a in self.allowed
 def repo_allowed(self,path):
  p=Path(path).resolve(); denied=[Path(x).resolve() for x in self.cfg.get('out_of_scope_repositories',[]) or []]; allowed=[Path(x).resolve() for x in self.cfg.get('in_scope_repositories',[]) or []]
  if any(d==p or d in p.parents for d in denied): return False
  return any(a==p or a in p.parents for a in allowed)
 def validate(self):
  if not self.allowed and not self.cfg.get('in_scope_repositories'): raise ScopeViolation('default-deny: empty scope')
  if self.cfg.get('rules_of_engagement',{}).get('live_state_changing_transactions',False): raise ScopeViolation('live state-changing transactions must remain disabled for autonomous mode')
