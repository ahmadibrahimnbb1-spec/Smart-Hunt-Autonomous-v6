from __future__ import annotations
import yaml
from datetime import date
from pathlib import Path
class PreconditionError(RuntimeError): pass
class Engagement:
 def __init__(self,root,cfg): self.root=Path(root); self.cfg=cfg; self.scope_path=self.root/'scope.yaml'
 @classmethod
 def load(cls,root):
  p=Path(root)/'scope.yaml'
  if not p.exists(): raise PreconditionError('missing scope.yaml')
  return cls(root,yaml.safe_load(p.read_text()) or {})
 @property
 def name(self): return self.cfg.get('program',self.root.name)
 @property
 def authorized_by(self): return str(self.cfg.get('authorized_by','')).strip()
 @property
 def contracts(self): return self.cfg.get('in_scope_contracts') or []
 @property
 def repos(self): return self.cfg.get('in_scope_repositories') or []
 def check_authorization(self):
  if not self.authorized_by: raise PreconditionError('authorized_by is empty')
  if not self.contracts and not self.repos: raise PreconditionError('no in-scope contracts or repositories')
  if self.cfg.get('engagement_type')=='pentest':
   w=self.cfg.get('testing_window') or {}; start=date.fromisoformat(str(w['start'])); end=date.fromisoformat(str(w['end'])); today=date.today()
   if not start<=today<=end: raise PreconditionError(f'testing window is closed/not open: {start}..{end}')
