from __future__ import annotations
import math
from typing import Any

SEVERITY={'critical':100,'high':75,'medium':45,'low':20,'informational':5}
TYPE_BONUS={'access_control':18,'accounting':17,'oracle':16,'reentrancy':15,'upgradeability':15,'signature':13,'token_logic':12,'precision':10,'governance':10}

def score(h:dict[str,Any], context:dict[str,Any]|None=None)->float:
    htype=str(h.get('type','')).lower(); impact=str(h.get('impact_estimate','')).lower()
    s=TYPE_BONUS.get(htype,8)
    for word,val in [('critical',35),('high',25),('medium',12),('financial',15),('privileged',8),('external',7),('user-controlled',5)]:
        if word in impact: s+=val
    s+=min(20,len(h.get('entrypoints') or [])*3)
    s+=min(12,len(h.get('mutations') or [])*2)
    if h.get('broken_invariant'): s+=8
    return float(s)

def prioritize(hypotheses:list[dict[str,Any]], limit:int=12):
    for h in hypotheses: h['_priority']=score(h)
    return sorted(hypotheses,key=lambda x:x.get('_priority',0),reverse=True)[:limit]
