from __future__ import annotations
import re
from pathlib import Path
from collections import defaultdict

IDENT = r'[A-Za-z_][A-Za-z0-9_]*'
FUNC = re.compile(r'function\s+('+IDENT+r')\s*\(([^)]*)\)([^\{;]*)\{', re.M)
MOD = re.compile(r'modifier\s+('+IDENT+r')\s*\([^)]*\)[^\{]*\{', re.M)
STATE_DECL = re.compile(r'^\s*((?:mapping\s*\([^;]+\)|(?:uint\d*|int\d*|address|bool|bytes\d*|bytes|string)\s+'+IDENT+r'(?:\s*\[[^\]]*\])?)(?:\s*=\s*[^;]+)?);', re.M)
EXTERNAL = re.compile(r'(?:\.call\s*(?:\{|\()|\.delegatecall\s*\(|\.staticcall\s*\(|\.send\s*\(|\.transfer\s*\(|IERC20\([^;]+\)\.transfer(?:From)?\s*\()')
ASSET = re.compile(r'\b(transferFrom|transfer|safeTransfer|safeTransferFrom|mint|burn|deposit|withdraw|redeem|borrow|repay|liquidate|swap|flashLoan|flash|claim|stake|unstake)\b', re.I)
ORACLE = re.compile(r'\b(price|oracle|rate|quote|twap|chainlink|latestRoundData|getPrice)\b', re.I)
PRIV = re.compile(r'\b(onlyOwner|onlyRole|onlyAdmin|_authorizeUpgrade|owner\s*\(|admin|guardian|pauser|operator|DEFAULT_ADMIN_ROLE|UPGRADER_ROLE)\b', re.I)
STATE_WRITE = re.compile(r'\b('+IDENT+r')\s*(?:\[[^\]]+\])?\s*(?:\+|-|\*=|/=|=|\+=|-=)', re.M)
STATE_READ = re.compile(r'\b('+IDENT+r')\b')


def body(text: str, pos: int) -> str:
    depth=0; seen=False; out=[]
    for ch in text[pos:]:
        if ch=='{': depth+=1; seen=True
        elif ch=='}':
            depth-=1
            if seen and depth==0: break
        if seen: out.append(ch)
    return ''.join(out)


def clean_name(decl: str) -> str | None:
    m=re.search(r'\b([A-Za-z_][A-Za-z0-9_]*)\s*(?:\[[^\]]*\])?\s*(?:=|$)', decl)
    return m.group(1) if m else None


def build_deep_model(repo: Path, selected: list[Path]) -> dict:
    state_names=set(); state_by_file={}
    parsed=[]
    for p in selected:
        text=p.read_text(errors='replace')
        rel=str(p.relative_to(repo))
        names=[]
        for m in STATE_DECL.finditer(text):
            n=clean_name(m.group(1));
            if n: state_names.add(n); names.append(n)
        state_by_file[rel]=names
        for m in FUNC.finditer(text):
            b=body(text,m.end()-1)
            header=m.group(0)
            parsed.append((rel,m.group(1),header,b))
    nodes=[]; data_edges=[]; asset_edges=[]; privilege_edges=[]; external_edges=[]
    for rel,name,header,b in parsed:
        writes=sorted(set(x.group(1) for x in STATE_WRITE.finditer(b) if x.group(1) in state_names))
        reads=sorted(set(x.group(1) for x in STATE_READ.finditer(b) if x.group(1) in state_names))
        reads=[x for x in reads if x not in writes or re.search(r'\b'+re.escape(x)+r'\b', b)]
        assets=sorted(set(x.lower() for x in ASSET.findall(b)))
        oracle=sorted(set(x.lower() for x in ORACLE.findall(b)))
        priv=sorted(set(x.lower() for x in PRIV.findall(header+b)))
        ext=EXTERNAL.findall(b)
        node={'file':rel,'function':name,'reads':reads,'writes':writes,'asset_actions':assets,'oracle_signals':oracle,'privilege_signals':priv,'external_interactions':len(ext)}
        nodes.append(node)
        for s in writes: data_edges.append({'type':'write','function':name,'state':s,'file':rel})
        for s in reads: data_edges.append({'type':'read','function':name,'state':s,'file':rel})
        for a in assets: asset_edges.append({'function':name,'action':a,'file':rel})
        for p in priv: privilege_edges.append({'function':name,'signal':p,'file':rel})
        if ext: external_edges.append({'function':name,'file':rel,'count':len(ext)})
    # Link functions sharing storage or asset actions: useful for targeted state-machine reasoning.
    dependency=[]
    for i,a in enumerate(nodes):
        for b in nodes[i+1:]:
            shared=set(a['reads']+a['writes']) & set(b['reads']+b['writes'])
            shared_assets=set(a['asset_actions']) & set(b['asset_actions'])
            if shared or shared_assets:
                dependency.append({'a':a['function'],'b':b['function'],'file_a':a['file'],'file_b':b['file'],'shared_state':sorted(shared),'shared_asset_actions':sorted(shared_assets)})
    return {'function_nodes':nodes,'storage_dataflow':data_edges,'asset_flow':asset_edges,'privilege_flow':privilege_edges,'external_interactions':external_edges,'state_dependencies':dependency[:2500]}
