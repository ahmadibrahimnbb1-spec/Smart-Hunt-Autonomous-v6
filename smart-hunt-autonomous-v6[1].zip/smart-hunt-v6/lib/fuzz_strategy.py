from __future__ import annotations
import re

def build_fuzz_plan(protocol: dict, invariants: list[dict]) -> list[dict]:
    plans=[]
    nodes=protocol.get('deep',{}).get('function_nodes',[])
    for inv in invariants:
        related=[]
        for n in nodes:
            blob=str(n).lower()
            if inv['kind']=='economic' and any(x in blob for x in ('balance','asset','share','deposit','withdraw','mint','burn','borrow','repay','liquidate')): related.append(n['function'])
            elif inv['kind']=='authorization' and n.get('privilege_signals'): related.append(n['function'])
            elif inv['kind']=='market' and n.get('oracle_signals'): related.append(n['function'])
            elif inv['kind']=='authentication' and re.search(r'permit|nonce|signature',blob): related.append(n['function'])
            elif inv['kind']=='upgradeability' and re.search(r'upgrade|delegatecall|implementation',blob): related.append(n['function'])
            elif inv['kind']=='numeric' and re.search(r'mul|div|decimal|round|wad|ray',blob): related.append(n['function'])
            elif inv['kind']=='control-flow' and n.get('external_interactions'): related.append(n['function'])
        plans.append({'invariant_id':inv['id'],'strategy':'targeted_property_fuzz','entrypoints':sorted(set(related))[:30],'mutations':['boundary values','zero/max values','repeated calls','role changes','state-order permutations'],'stop_condition':'only promote a finding after deterministic local evidence supports the invariant violation'})
    return plans
