from __future__ import annotations
import json, hashlib
from pathlib import Path
from typing import Any

class HuntMemory:
    def __init__(self,root): self.root=Path(root); self.path=self.root/'state'/'memory.json'; self.path.parent.mkdir(parents=True,exist_ok=True); self.data=self._load()
    def _load(self):
        try: return json.loads(self.path.read_text()) if self.path.exists() else {'hypotheses':{},'patterns':{},'rejections':{},'findings':{}}
        except Exception: return {'hypotheses':{},'patterns':{},'rejections':{},'findings':{}}
    def save(self): self.path.write_text(json.dumps(self.data,indent=2,default=str))
    def key(self,h): return hashlib.sha256(json.dumps({'type':h.get('type'),'files':sorted(h.get('files',[])),'invariant':h.get('broken_invariant')},sort_keys=True).encode()).hexdigest()[:20]
    def known(self,h): return self.key(h) in self.data['hypotheses']
    def record(self,h,status,result=None):
        k=self.key(h); self.data['hypotheses'][k]={'status':status,'type':h.get('type'),'files':h.get('files',[]),'result':result}; self.save()
    def rejected(self,h): return self.data['hypotheses'].get(self.key(h),{}).get('status')=='rejected'
    def similar_findings(self): return list(self.data.get('findings',{}).values())
    def record_finding(self,f):
        k=hashlib.sha256(json.dumps({x:f.get(x) for x in ('title','root_cause','affected_files')},sort_keys=True,default=str).encode()).hexdigest()[:20]; self.data['findings'][k]=f; self.save()
