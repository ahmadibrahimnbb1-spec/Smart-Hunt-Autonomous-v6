#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
python3 -m pip install --user pyyaml >/dev/null 2>&1 || true
chmod +x "$ROOT/bin/smart-hunt"
echo "Smart-Hunt installed. Run: $ROOT/bin/smart-hunt doctor"
